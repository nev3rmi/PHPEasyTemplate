<?php
$_sqlEncryptString = "";
?>