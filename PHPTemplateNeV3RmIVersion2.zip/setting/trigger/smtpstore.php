<?php
$_smtpEncryptString = "";
?>