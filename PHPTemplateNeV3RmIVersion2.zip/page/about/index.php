<?php
require_once $_SERVER['DOCUMENT_ROOT']."/page/about/aboutContent.php";
?>