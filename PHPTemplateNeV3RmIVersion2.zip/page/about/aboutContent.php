<?php
$thisPageName = "About";
$thisPageMeta = "";
$thisPageHeading = $thisPageName;
$thisPageSubHeading = "Test";
$thisPageContent = $_SERVER['DOCUMENT_ROOT']."/page/about/view/aboutView.php";
$thisPageBreadCrumbUse = 1;
require_once $_SERVER['DOCUMENT_ROOT']."/page/_layout/_layout.php";


//echo realpath('.');
?>