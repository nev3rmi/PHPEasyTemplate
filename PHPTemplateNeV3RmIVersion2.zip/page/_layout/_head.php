<head>
<?php require_once $_phpPath."page/_layout/head/_generalmeta.php"; ?>
<title><?php echo $thisPageName?> | <?php echo $_siteName ?></title>
<?php require_once $_phpPath."js/js_top.php"; ?>
</head>