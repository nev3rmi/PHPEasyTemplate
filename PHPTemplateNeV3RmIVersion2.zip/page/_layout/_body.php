<body>
<?php require_once $_phpPath."page/_layout/body/_navigationbar.php"; ?>
<?php require_once $_phpPath."page/_layout/body/_header.php"; ?>
<?php require_once $_phpPath."page/_layout/body/_container.php"; ?>
<?php require_once $_phpPath."css/css.php"; ?>
<?php require_once $thisPageCSS?>
<?php require_once $_phpPath."js/js_bottom.php"; ?>
<?php require_once $thisPageJS?>
</body>