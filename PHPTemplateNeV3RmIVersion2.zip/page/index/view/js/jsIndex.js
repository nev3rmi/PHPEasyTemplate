// JavaScript Document
$('.carousel').carousel({
	interval: 5000 //changes the speed
});