<?php
require_once realpath('.')."/page/index/indexContent.php";
?>