<link rel="stylesheet" href="<?php echo $_url;?>css/bootstrap-theme.min.css">
<link rel="stylesheet" href="<?php echo $_url;?>css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo $_url;?>css/custom.css">
<link rel="stylesheet" href="<?php echo $_url;?>css/font-awesome.min.css">