<?php
// Consider to put jquery on top to run partial inline script
?>