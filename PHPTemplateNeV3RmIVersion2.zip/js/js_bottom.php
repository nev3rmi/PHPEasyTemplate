<script src="<?php echo $_url;?>js/jquery-3.1.1.min.js" ></script>
<script src="<?php echo $_url;?>js/bootstrap.min.js" ></script>