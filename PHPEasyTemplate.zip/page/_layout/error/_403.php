<?php
$thisPageName = "403 ERROR";
$thisPageMeta = "";
$thisPageHeading = "ERROR";
$thisPageSubHeading = "403";
$thisPageContent = $_SERVER['DOCUMENT_ROOT']."/page/_layout/error/view/_404.php";
require_once $_SERVER['DOCUMENT_ROOT']."/page/_layout/_layout.php";
//echo realpath('.');
?>