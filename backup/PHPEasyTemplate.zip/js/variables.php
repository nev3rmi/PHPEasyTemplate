<script type="text/javascript">
function getURL(){
	return "<?php echo $_url?>";
}
</script>