<form method="post" action="./controller.php">
<input type="text" name="hostname" placeholder="hostname">
<input type="text" name="username" placeholder="username">
<input type="text" name="password" placeholder="password">
<input type="text" name="database" placeholder="database">
<input type="submit" value="Submit">
</form>