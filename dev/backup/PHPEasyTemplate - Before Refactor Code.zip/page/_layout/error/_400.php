<?php
$thisPageName = "400 ERROR";
$thisPageMeta = "";
$thisPageHeading = "ERROR";
$thisPageSubHeading = "400";
$thisPageContent = $_SERVER['DOCUMENT_ROOT']."/page/_layout/error/view/_404.php";
require_once $_SERVER['DOCUMENT_ROOT']."/page/_layout/_layout.php";
//echo realpath('.');
?>