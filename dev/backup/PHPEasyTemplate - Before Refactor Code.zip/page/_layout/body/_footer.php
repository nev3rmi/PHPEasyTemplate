<footer>
  <div class="row">
    <div class="col-lg-12">
      <p>Copyright &copy; <?php echo $_sitePublisher." ".$_siteCopyrightYear?></p>
    </div>
  </div>
  <!-- /.row --> 
</footer>
