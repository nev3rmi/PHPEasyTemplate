<?php
echo '<script>function privateIndexJS(){return;}</script>';
?>