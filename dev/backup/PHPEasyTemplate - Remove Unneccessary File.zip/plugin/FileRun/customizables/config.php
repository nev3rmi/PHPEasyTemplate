<?php
$config['app']['software_update']['url'] = 'https://www.filerun.com/updates/ionCube7';