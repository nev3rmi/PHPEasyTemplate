<?php
$thisPageName = "404 ERROR";
$thisPageMeta = "";
$thisPageHeading = "ERROR";
$thisPageSubHeading = "404";
$thisPageContent = $_SERVER['DOCUMENT_ROOT']."/page/_layout/error/view/_404.php";
require_once $_SERVER['DOCUMENT_ROOT']."/page/_layout/_layout.php";
//echo realpath('.');
?>